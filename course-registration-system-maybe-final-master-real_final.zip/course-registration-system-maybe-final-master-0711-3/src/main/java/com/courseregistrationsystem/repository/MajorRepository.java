package com.courseregistrationsystem.repository;

import com.courseregistrationsystem.domain.Major;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MajorRepository extends JpaRepository<Major, Long> {
}
