package com.courseregistrationsystem.repository;

import com.courseregistrationsystem.domain.TakeClass;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface TakeClassRepository extends JpaRepository<TakeClass, Long> {
    @Query("select c from TakeClass c where c.classes.classId = :classId")
    List<TakeClass> findByClassId(@Param("classId") Long classId);

}
