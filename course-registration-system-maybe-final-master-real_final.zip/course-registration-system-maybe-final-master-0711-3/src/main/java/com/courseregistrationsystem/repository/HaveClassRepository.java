package com.courseregistrationsystem.repository;

import com.courseregistrationsystem.domain.HaveClass;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface HaveClassRepository extends JpaRepository<HaveClass, Long> {

}
