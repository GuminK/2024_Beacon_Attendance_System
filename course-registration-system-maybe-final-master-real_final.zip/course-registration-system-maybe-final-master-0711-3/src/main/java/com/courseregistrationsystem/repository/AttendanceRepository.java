package com.courseregistrationsystem.repository;
import com.courseregistrationsystem.domain.Attendance;
import com.courseregistrationsystem.domain.TakeClass;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface AttendanceRepository extends JpaRepository<Attendance, Long>{

    @Query("select c from Attendance c where c.takeClass.takeId = :takeId")
    List<Attendance> findByUser(@Param("takeId") Long takeId);

    @Query("select c from Attendance c where c.classes.classId = :classId")
    List<Attendance> findByClassId(@Param("classId") Long classId);
}
