package com.courseregistrationsystem.repository;

import com.courseregistrationsystem.domain.Classes;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ClassesRepository extends JpaRepository<Classes, Long> {

    @Query("select c from Classes c where c.course.courseId = :courseId")
    List<Classes> findByCourse(@Param("courseId") Long courseId);

    @Query("select c from Classes c where c.professorName = :professorName")
    List<Classes> findByProfessorName(@Param("professorName") String professorName);
}
