package com.courseregistrationsystem.service;

import com.courseregistrationsystem.domain.HaveClass;
import com.courseregistrationsystem.repository.CourseRepository;
import com.courseregistrationsystem.repository.HaveClassRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class HaveClassService {

    private final HaveClassRepository haveClassRepository;
    public HaveClass findById(Long haveId) {
        return haveClassRepository.findById(haveId)
                .orElseThrow(() -> new IllegalArgumentException("Failed: No Course Info"));
    }
}
