package com.courseregistrationsystem.service;

import com.courseregistrationsystem.controller.dto.TakeClassDto;
import com.courseregistrationsystem.domain.Attendance;
import com.courseregistrationsystem.domain.Classes;
import com.courseregistrationsystem.domain.Course;
import com.courseregistrationsystem.domain.TakeClass;
import com.courseregistrationsystem.repository.ClassesRepository;
import com.courseregistrationsystem.repository.TakeClassRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@RequiredArgsConstructor
@Slf4j
@Service
public class SchedulerService {

    private final ClassesRepository classesRepository;
    private final TakeClassService takeClassService;
    private final TakeClassRepository takeClassRepository;
    private final AttendanceService attendanceService;

    @Scheduled(fixedDelay = 1000) // 1초마다 실행
    public void run(){

        List<Classes> classesList = classesRepository.findAll();
        Attendance LastAttendance=null;

        for(int i = 0; i < classesList.size(); i++){
            Classes classes = classesList.get(i);
            LocalDateTime now = LocalDateTime.now();

            LocalDateTime CT = classes.getCheckTime();
            Duration duration = Duration.between(CT,now);

            if (CT == null) {
                log.error("Check time is null for class: " + classes.getClassId());
                continue; // 다음 루프로 건너뛰기
            }



            if(duration.getSeconds()>=30 && (classes.getAttCode() != 0)){
                log.info("30초가 초과되었음. duration: "+ duration);
                classes.setAttCode(0);
                classesRepository.save(classes);
                // 출석 결석처리 관련
                List<TakeClass> takeClassList = takeClassRepository.findByClassId(classes.getClassId());


                for(TakeClass takeClass : takeClassList) {
                    Long classId = takeClass.getClasses().getClassId();
                    attendanceService.update(classId, 3);
                }
                // 결석 처리 관련 end
            }

        }
    }
}
