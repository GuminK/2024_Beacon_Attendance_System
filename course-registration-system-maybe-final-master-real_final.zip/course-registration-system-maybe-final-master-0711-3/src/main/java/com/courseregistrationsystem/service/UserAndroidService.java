package com.courseregistrationsystem.service;

import com.courseregistrationsystem.controller.dto.UserLoginDto;
import com.courseregistrationsystem.controller.dto.UserResponseDto;
import com.courseregistrationsystem.controller.dto.UserSignUpDto;
import com.courseregistrationsystem.controller.dto.UserUpdateRequestDto;
import com.courseregistrationsystem.domain.User;
import com.courseregistrationsystem.repository.MajorRepository;
import com.courseregistrationsystem.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class UserAndroidService {

    private final UserRepository userRepository;
    private final MajorRepository majorRepository;
    private final BCryptPasswordEncoder passwordEncoder;

    public Long join(UserSignUpDto signUpDto) {
        userRepository.findByLoginId(signUpDto.getLoginId())
                .ifPresent(user -> {
                    throw new IllegalArgumentException("Failed: Already Exist ID!");
                });

        if (!signUpDto.getPassword().equals(signUpDto.getPasswordConfirm())) {
            throw new IllegalArgumentException("Failed: Please Check Password!");
        }

        User user = User.signupBuilder()
                .loginId(signUpDto.getLoginId())
                .password(passwordEncoder.encode(signUpDto.getPassword()))
                .username(signUpDto.getUsername())
                .email(signUpDto.getEmail())
                .phoneNumber(signUpDto.getPhoneNumber())
                .major(majorRepository.findById(signUpDto.getMajorId()).get())
                .build();
        return userRepository.save(user).getUserId();
    }

    public String Login(UserLoginDto userLoginDto){
        if(userRepository.findByLoginId(userLoginDto.getLoginId()).isPresent()){
//            if(userRepository.findByLoginId(userLoginDto.getLoginId()).get().getPassword() == passwordEncoder.encode(userLoginDto.getPassword())){
//                System.out.println("입력한 비밀번호가 등록된 정보와 같음~");
//            }
            if(passwordEncoder.matches(userLoginDto.getPassword(), userRepository.findByLoginId(userLoginDto.getLoginId()).get().getPassword())){
                System.out.println("입력한 비밀번호와 등록된 비밀번호가 같음~");
                System.out.println("login success");
                return "1";
            }
            else return "2";
        }
        else return "2";
    }

    public UserResponseDto findByLoginId(String loginId){
        User user = userRepository.findByLoginId(loginId)
                .orElseThrow(() -> new IllegalArgumentException("Failed: No User Info"));
        return new UserResponseDto(user);
    }

}
