package com.courseregistrationsystem.service;
import com.courseregistrationsystem.controller.dto.AttendanceTestDto;
import com.courseregistrationsystem.controller.dto.UserResponseDto;
import com.courseregistrationsystem.domain.*;
import com.courseregistrationsystem.repository.AttendanceRepository;

import com.courseregistrationsystem.repository.HaveClassRepository;
import com.courseregistrationsystem.repository.TakeClassRepository;
import com.courseregistrationsystem.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class AttendanceService {
    private final UserService userService;
    private final AttendanceRepository attendanceRepository;
    private final TakeClassRepository takeClassRepository;
    private final UserRepository userRepository;
    private final HaveClassRepository haveClassRepository;

    /*public List<Attendance> findByUser(Long userId) {
        return attendanceRepository.findByUser(userId);
    }*/
    public List<Attendance> findAll() {
        return attendanceRepository.findAll();
    }

    public List<Attendance> attUser(Long takeId){
        TakeClass takeClass = takeClassRepository.findById(takeId).get();

        return attendanceRepository.findByUser(takeClass.getTakeId());
    }

    public void attAllDelete(Long takeId){
        attendanceRepository.deleteAll(attUser(takeId));
        System.out.println("att삭제");
    }


    public void saveAtt(Long userId, Long takeId ,int Checkstate){
        UserResponseDto userResponseDto = userService.findById(userId);
// user, classes, takeclass, attendanceOx

        TakeClass takeClass = takeClassRepository.findById(takeId)
                .orElseThrow(() -> new IllegalArgumentException("Failed: No takeClass Info"));;
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("Failed: No User Info"));

        Classes classes = takeClass.getClasses();

        //TakeClass takeClass = takeClassRepository.findByClassIdAndUserId(classId, userId);


        Attendance attendance = Attendance.builder()
                .user(user)
                .classes(classes)
                .takeClass(takeClass)
                .attendanceOx(Checkstate)
                .build();

        attendanceRepository.save(attendance);
    }

    public void updateAtt(Long attendanceNum, int Checkstate){
        Attendance attendance = attendanceRepository.getById(attendanceNum);
        attendance.setAttendanceOx(Checkstate);

        attendanceRepository.save(attendance);
    }

    public void update(Long classId, int Checkstate) {
        List<Attendance> attendances = attendanceRepository.findByClassId(classId);
        for (Attendance attendance : attendances) {
            if(attendance.getAttendanceOx() == 0)
            {
                attendance.setAttendanceOx(Checkstate);
            }
        }
    }

    public void update2(Long userId, Long takeId ,int Checkstate) {
        List<Attendance> attendances = attendanceRepository.findByUser(takeId);
        for (Attendance attendance : attendances) {
            if(attendance.getAttendanceOx() == 0 && attendance.getUser().getUserId() == userId)
            {
                attendance.setAttendanceOx(Checkstate);
            }
        }
    }
}
