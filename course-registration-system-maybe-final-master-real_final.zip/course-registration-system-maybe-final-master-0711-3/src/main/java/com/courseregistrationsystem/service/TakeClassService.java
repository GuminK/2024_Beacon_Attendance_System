package com.courseregistrationsystem.service;

import com.courseregistrationsystem.controller.dto.ClassesSignUpDto;
import com.courseregistrationsystem.controller.dto.TakeClassDto;
import com.courseregistrationsystem.controller.dto.UserResponseDto;
import com.courseregistrationsystem.domain.*;
import com.courseregistrationsystem.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Transactional
public class TakeClassService {

    private final TakeClassRepository takeClassRepository;
    private final UserRepository userRepository;
    private final ClassesRepository classesRepository;
    private final MajorRepository majorRepository;
    private final CourseRepository courseRepository;
    private final HaveClassRepository haveClassRepository;
    private final AttendanceRepository attendanceRepository;

    @Transactional
    public Long join1(ClassesSignUpDto classSignUpDto) {
        Course course = Course.builder()
                .courseName(classSignUpDto.getCourseName())
                .major(majorRepository.findById(classSignUpDto.getMajorId()).get())
                .build();

        return courseRepository.save(course).getCourseId();
    }

    public Long join2(ClassesSignUpDto classSignUpDto, Long courseId) {
        Classes classes = Classes.builder()
                .course(courseRepository.findById(courseId).get())
                .classNumber(classSignUpDto.getClassNumber())
                .professorName(classSignUpDto.getProfessorName())
                .maxStudentNum(classSignUpDto.getMaxStudentNum())
                .build();

        return classesRepository.save(classes).getClassId();
    }

    @Transactional
    public Long save(Long userId, Long classId) {
        User user = userRepository.findById(userId).get();
        Classes classes = classesRepository.findById(classId).get();

        if (classes.isFull()) throw new IllegalArgumentException("Failed: Full");

        Optional<TakeClass> any = user.getTakeClasses().stream()
                .filter(takeClass ->
                        takeClass.getClasses().getCourse().getCourseId().equals(classes.getCourse().getCourseId())).findAny();

        if (any.isPresent()) throw new IllegalArgumentException("Failed: Already Registered!");

        TakeClass takeClass = takeClassRepository.save(
                TakeClass.builder()
                    .user(user)
                    .classes(classes)
                    .build());

        user.registration(takeClass);
        classes.registration();

        return takeClass.getTakeId();
    }

    @Transactional
    public Long hsave(Long userId, Long classId) {
        User user = userRepository.findById(userId).get();
        Classes classes = classesRepository.findById(classId).get();

        if (classes.isFull()) throw new IllegalArgumentException("Failed: Full");

        Optional<HaveClass> any = user.getHaveClasses().stream()
                .filter(haveClass ->
                        haveClass.getMyclass().getCourse().getCourseName().equals(classes.getCourse().getCourseName())).findAny();

        if (any.isPresent()) throw new IllegalArgumentException("Failed: Already Registered!");

        HaveClass haveClass = haveClassRepository.save(
                HaveClass.builder()
                        .user(user)
                        .classes(classes)
                        .build());

        return haveClass.getHaveId();
    }

    @Transactional
    public void delete(Long takeId) {
        TakeClass takeClass = takeClassRepository.findById(takeId).get();

        User user = userRepository.findById(takeClass.getUser().getUserId()).get();
        user.cancel(takeClass);

        Classes classes = classesRepository.findById(takeClass.getClasses().getClassId()).get();
        classes.cancel();

        takeClassRepository.delete(takeClass);
    }

    @Transactional
    public void hdelete(Long haveId) {
        HaveClass haveClass = haveClassRepository.findById(haveId).get();

        List<Attendance> attendances = attendanceRepository.findByClassId(haveClass.getMyclass().getClassId());

        // classId로 TakeClass 엔티티 조회
        List<TakeClass> takeClasses = takeClassRepository.findByClassId(haveClass.getMyclass().getClassId());

        // 조회된 TakeClass 엔티티 삭제
        attendanceRepository.deleteAll(attendances);
        takeClassRepository.deleteAll(takeClasses);

        haveClassRepository.delete(haveClass);

        Classes classes = classesRepository.findById(haveClass.getMyclass().getClassId()).get();
        classesRepository.delete(classes);

        Course course = courseRepository.findById(haveClass.getMyclass().getCourse().getCourseId()).get();
        courseRepository.delete(course);

        User user = userRepository.findById(haveClass.getProfessor().getUserId()).get();
        user.delete(haveClass);
    }


    public List<TakeClass> findByClass(Long haveId){
        HaveClass haveClass = haveClassRepository.findById(haveId).get();

        return takeClassRepository.findByClassId(haveClass.getMyclass().getClassId());
    }

    public List<TakeClass> findByClassId(Long classId){
        return takeClassRepository.findByClassId(classId);
    }

    public TakeClass findByTakeId(Long takeId){
        Optional<TakeClass> takeClassOptional = takeClassRepository.findById(takeId);
        TakeClass takeclass = takeClassOptional.get();

        return takeclass;
    }

    public List<TakeClass> findAll() {
            return takeClassRepository.findAll();
    }

    public List<TakeClassDto> getUserCourseInfo(String loginId) {
        User user = userRepository.findByLoginId(loginId)
                .orElseThrow(() -> new IllegalArgumentException("Failed: No User Info"));

        List<TakeClassDto> takeClassDto = new ArrayList<>();

        List<TakeClass> takeClasses = user.getTakeClasses();

        for(TakeClass takeClass : takeClasses) {
            Long takeId = takeClass.getTakeId();
            Course course = takeClass.getClasses().getCourse();
            String courseName = course.getCourseName();

            takeClassDto.add(new TakeClassDto(takeId, courseName));
        }

        return takeClassDto;
    }


}
