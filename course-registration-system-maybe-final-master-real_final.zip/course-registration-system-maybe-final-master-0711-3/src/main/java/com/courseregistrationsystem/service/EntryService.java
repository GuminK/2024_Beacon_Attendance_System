package com.courseregistrationsystem.service;

import com.courseregistrationsystem.controller.dto.EntryDto;
import com.courseregistrationsystem.controller.dto.UserSignUpDto;
import com.courseregistrationsystem.domain.Entry;
import com.courseregistrationsystem.domain.HaveClass;
import com.courseregistrationsystem.domain.User;
import com.courseregistrationsystem.repository.EntryRepository;
import com.courseregistrationsystem.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class EntryService {

    private final EntryRepository entryRepository;
    private final UserRepository userRepository;

    public List<Entry> findAll(){return entryRepository.findAll();}

    public Long save(Long userId, int entryexit) {
        User user = userRepository.findById(userId).get();

        Entry entry = entryRepository.save(
                Entry.builder()
                        .user(user)
                        .entryexit(entryexit)
                        .build());

        return entry.getEntryId();
    }

    public void update(Long userId, int entryexit) {
        List<Entry> entrys = entryRepository.findByUserId(userId);

        System.out.println(entrys);

        System.out.println("for문 실행전");

        for (Entry entry : entrys) {
            if (entry.getEntryexit() != entryexit) {
                entry.update(entryexit);
                entryRepository.save(entry);
                System.out.println("for문 실행중");
                break; // 첫 번째로 변경한 후 종료
            }
        }
    }
}
