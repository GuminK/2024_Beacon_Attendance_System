/*
package com.courseregistrationsystem.controller.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ClassesUpdateRequestDto {

    private int classNumber;
    private String professorName;
    private int maxStudentNum;
    private int curStudentNum;

    public ClassesUpdateRequestDto(int classNumber, String professorName, int maxStudentNum, int curStudentNum) {
        this.classNumber = classNumber;
        this.professorName = professorName;
        this.maxStudentNum = maxStudentNum;
        this.curStudentNum = curStudentNum;
    }
}
*/