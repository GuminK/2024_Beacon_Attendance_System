package com.courseregistrationsystem.controller;


import com.courseregistrationsystem.controller.dto.UserResponseDto;
import com.courseregistrationsystem.domain.User;
import com.courseregistrationsystem.repository.TakeClassRepository;
import com.courseregistrationsystem.service.TakeClassService;
import com.courseregistrationsystem.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
@Slf4j
public class TakeClassAndroidController {

    private final TakeClassService takeClassService;
    private final TakeClassRepository takeClassRepository;
    private final UserService userService;

    @GetMapping("/user/info")
    public UserResponseDto testGetUser(@RequestBody String loginId){
        return userService.findByLoginId(loginId);
    }
}
