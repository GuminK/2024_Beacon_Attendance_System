package com.courseregistrationsystem.controller;

import com.courseregistrationsystem.controller.dto.UserResponseDto;
import com.courseregistrationsystem.domain.Attendance;
import com.courseregistrationsystem.domain.Classes;
import com.courseregistrationsystem.domain.TakeClass;
import com.courseregistrationsystem.domain.User;
import com.courseregistrationsystem.repository.AttendanceRepository;
import com.courseregistrationsystem.repository.ClassesRepository;
import com.courseregistrationsystem.repository.TakeClassRepository;
import com.courseregistrationsystem.service.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;

@Controller
@RequiredArgsConstructor
@Slf4j
public class AttendanceController {
    private final UserService userService;
    private final MajorService majorService;
    private final ClassesService classesService;
    private final TakeClassService takeClassService;
    private final AttendanceService attendanceService;
    private final ClassesRepository classesRepository;
    private final AttendanceRepository attendanceRepository;
    private final TakeClassRepository takeClassRepository;


    @GetMapping("/attendance/create")
    public String attendanceCreateGet(@AuthenticationPrincipal User user, @RequestParam(value="msg", required = false) String msg, Model model){

        model.addAttribute("username", user.getUsername());

        List<Classes> classes = classesService.findByProfessorName(user.getUsername());
        model.addAttribute("classes",classes);
        return "/attendance/create";
    }

    @GetMapping("/attendance/create/{id}")
    public String attendanceCreateNum(@AuthenticationPrincipal User user, @RequestParam(value="msg", required = false) String msg, @PathVariable("id") Long classId, Model model){
        Random random = new Random();
//        random.nextInt(999);
        int code = random.nextInt(999);
        Classes classes = classesService.findById(classId);

        if(classes.getAttCode()==0)
        {
            classes.setAttCode(code);
            classes.setCheckTime(LocalDateTime.now());
            classesRepository.save(classes);
            msg = "출석이 생성되었습니다." + code;
            log.info("생성된 코드는 " + code);
            model.addAttribute("msg", msg);

            List<TakeClass> takeClassList = takeClassRepository.findByClassId(classes.getClassId());

            for(TakeClass takeClass : takeClassList) {
                Long takeId = takeClass.getTakeId();
                List<Attendance> attendanceList = attendanceService.attUser(takeId);
                attendanceService.saveAtt(takeClass.getUser().getUserId(), takeId, 0);
            }

        }

        else
        {
            msg = "이미 생성되었습니다.";
            model.addAttribute("msg", msg);
        }

        List<Classes> classesList = classesService.findByProfessorName(user.getUsername());

        model.addAttribute("username", user.getUsername());
        model.addAttribute("classes",classesList);

        return "/attendance/create";
    }

    // 2024_02_28
    @GetMapping("/attendance/check")
    public String attendanceCheckGet(@AuthenticationPrincipal User user, Model model){

        UserResponseDto userResponseDto = userService.findById(user.getUserId());

        model.addAttribute("username", userResponseDto.getUsername());
        model.addAttribute("takeClasses", userResponseDto.getTakeClasses());

        return "attendance/check";
    }

    @PostMapping("/attendance/check/{id}")
    public String attendanceCheckPost(@RequestParam(value="msg", required = false) String msg, @AuthenticationPrincipal User user, @PathVariable("id") Long takeId, Model model, HttpServletRequest request){
        UserResponseDto userResponseDto = userService.findById(user.getUserId());

        model.addAttribute("username", userResponseDto.getUsername());
        model.addAttribute("takeClasses", userResponseDto.getTakeClasses());

        int code = Integer.parseInt(request.getParameter("code"));
        TakeClass takeClass = takeClassService.findByTakeId(takeId);

        Classes classes = takeClass.getClasses();

        LocalDateTime now = LocalDateTime.now();

        LocalDateTime CT = classes.getCheckTime();
        Duration duration = Duration.between(CT,now);
        log.info("duration = "+duration.getSeconds());

//        List<Attendance> AttendanceList = userResponseDto.getAttendances();
//        AttendanceList.get()

        if(classes.getAttCode() == 0){
            msg = "출석이 생성되지 않았습니다";
            model.addAttribute("msg", msg);

            return "attendance/check";
        }

        if(duration.getSeconds()>=30){
            msg = "출석 실패 - 시간이 초과되었습니다";
            log.info("10분이 초과되었음. duration: "+ duration);
            model.addAttribute("msg", msg);
//            classes.setAttCode(0);
//            classesRepository.save(classes);

            return "attendance/check";
        }

        if((classes.getAttCode() > 0 && code == classes.getAttCode()) && true)
        {
            // Attendance 테이블에 채워넣기
            attendanceService.saveAtt(user.getUserId(), takeId,1);

            msg = "출석 성공";
            log.info(userResponseDto.getUsername()+"님의 출석 완료 현 시간 : "+classes.getCheckTime());

        }

        else
        {
            log.info("if else 실행");
            msg = "출석 실패";
            log.info(userResponseDto.getUsername() + "님의 출석 실패");
        }

        model.addAttribute("msg", msg);

        return "attendance/check";
    }

    @GetMapping("/attendance/editAtt")
    public String attendanceEditAtt1(@AuthenticationPrincipal User user, @RequestParam(value="msg", required = false) String msg, Model model){

        model.addAttribute("username", user.getUsername());

        List<Classes> classes = classesService.findByProfessorName(user.getUsername());
        model.addAttribute("classes",classes);

        return "/attendance/editAtt1";
    }

    @GetMapping("/attendance/editAtt/{id}")
    public String attendanceEditAtt2(@AuthenticationPrincipal User user, @RequestParam(value="msg", required = false) String msg, @PathVariable("id") Long classId, Model model){
        Classes classes = classesService.findById(classId);

        List<Classes> classesList = classesService.findByProfessorName(user.getUsername());

        List<TakeClass> takeClassList = takeClassService.findByClassId(classId);

        model.addAttribute("takeclasses", takeClassList);
        model.addAttribute("username", user.getUsername());
        model.addAttribute("classes",classes);

        return "/attendance/editAtt2";
    }

    @GetMapping("/attendance/editAtt2/{id}")
    public String attendanceEditAtt3(@AuthenticationPrincipal User user, @RequestParam(value="msg", required = false) String msg, @PathVariable("id") Long takeId, Model model){

        TakeClass testTakeClass = takeClassService.findByTakeId(takeId);


        List<Attendance> attendanceList = attendanceService.attUser(takeId);
        model.addAttribute("attendanceList", attendanceList);
        model.addAttribute("username", testTakeClass.getUser().getUsername());
        model.addAttribute("takeclassId", takeId);


        return "/attendance/editAtt3";
    }




    @GetMapping("/attendance/editAtt4/{num}/{id}")
    public String attendanceEditAtt4(@AuthenticationPrincipal User user, @RequestParam(value="msg", required = false) String msg, @PathVariable("id") Long takeId, @PathVariable("num") Long attendanceNum, Model model){

        TakeClass testTakeClass = takeClassService.findByTakeId(takeId);

        List<Attendance> attendanceList = attendanceService.attUser(takeId);
        model.addAttribute("attendanceList", attendanceList);
        model.addAttribute("username", testTakeClass.getUser().getUsername());
        model.addAttribute("takeclassId", takeId);

        Attendance attendance = attendanceRepository.getById(attendanceNum);

        if(attendance.getAttendanceOx()==0){
            attendanceService.updateAtt(attendanceNum, 1);
        }
        else if(attendance.getAttendanceOx()==1){
            attendanceService.updateAtt(attendanceNum, 2);
        }
        else if(attendance.getAttendanceOx()==2){
            attendanceService.updateAtt(attendanceNum, 3);
        }
        else if(attendance.getAttendanceOx()==3){
            attendanceService.updateAtt(attendanceNum, 1);
        }
        else attendanceService.updateAtt(attendanceNum, 3);


        return "/attendance/editAtt3";
    }
}