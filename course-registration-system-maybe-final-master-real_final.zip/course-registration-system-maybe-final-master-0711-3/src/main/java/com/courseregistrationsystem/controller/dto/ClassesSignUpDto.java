package com.courseregistrationsystem.controller.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter @Setter
@NoArgsConstructor
public class ClassesSignUpDto {

    private String professorName;
    private int classNumber;
    private int maxStudentNum;

    private Long majorId;
    private String courseName;

    @Builder
    public ClassesSignUpDto(String professorName, int classNumber, int maxStudentNum, Long majorId, String courseName) {
        this.professorName = professorName;
        this.classNumber = classNumber;
        this.maxStudentNum = maxStudentNum;
        this.majorId = majorId;
        this.courseName = courseName;
    }
}