package com.courseregistrationsystem.controller;

import com.courseregistrationsystem.controller.dto.AttendanceTestDto;
import com.courseregistrationsystem.controller.dto.TakeClassDto;
import com.courseregistrationsystem.controller.dto.UserResponseDto;
import com.courseregistrationsystem.domain.*;
import com.courseregistrationsystem.repository.ClassesRepository;
import com.courseregistrationsystem.service.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequiredArgsConstructor
@Slf4j
public class AttendanceAndroidController {

    private final UserService userService;
    private final MajorService majorService;
    private final ClassesService classesService;
    private final TakeClassService takeClassService;
    private final AttendanceService attendanceService;
    private final ClassesRepository classesRepository;

    @PostMapping("/att/list")
    public List<TakeClassDto> attList(@RequestBody String loginId){
        return takeClassService.getUserCourseInfo(loginId);
    }

    @PostMapping("/att/check")
    public String attCheckPost(@RequestBody String loginId, @AuthenticationPrincipal User user, Long takeId, Long code) {
        UserResponseDto userResponseDto = userService.findById(user.getUserId());

        TakeClass takeClass = takeClassService.findByTakeId(takeId);

        Classes classes = takeClass.getClasses();

        LocalDateTime now = LocalDateTime.now();

        LocalDateTime CT = classes.getCheckTime();
        Duration duration = Duration.between(CT,now);
        log.info("duration = " + duration.getSeconds());

        if(classes.getAttCode() == 0){
            String msg = "출석이 생성되지 않았습니다";

            return msg;
        }

        if(duration.getSeconds() >= 30){
            String msg = "출석 실패 - 시간이 초과되었습니다";
            log.info("10분이 초과되었음. duration: "+ duration);
//            classes.setAttCode(0);
//            classesRepository.save(classes);

            return msg;
        }

        if((classes.getAttCode() > 0 && code > 0))
        {
            // Attendance 테이블에 채워넣기
            attendanceService.update2(user.getUserId(), takeId,1);

            String msg = "출석 성공";
            log.info(userResponseDto.getUsername() + "님의 출석 완료 현 시간 : " + classes.getCheckTime());

            return msg;
        }

        else
        {
            log.info("if else 실행");
            String msg = "출석 실패";
            log.info(userResponseDto.getUsername() + "님의 출석 실패");

            return msg;
        }
    }

    @PostMapping("/att/checkTest")
    public String attcheckTest(@RequestBody TakeClassDto takeClassDto){
        TakeClass takeClass = takeClassService.findByTakeId(takeClassDto.getTakeId());
//        attendanceService.saveAtt(takeClass.getUser().getUserId(), takeClassDto.getTakeId(), 1);



        String testmsg = takeClassDto.getCourseName();
        String msg = testmsg + "출석 -완-";

        Classes classes = takeClass.getClasses();

        LocalDateTime now = LocalDateTime.now();

        LocalDateTime CT = classes.getCheckTime();
        Duration duration = Duration.between(CT,now);
        log.info("duration = " + duration.getSeconds());

        if(classes.getAttCode() == 0){
            msg = "출석이 생성되지 않았습니다";

            return msg;
        }

        if(duration.getSeconds() >= 30){
            msg = "출석 실패 - 시간이 초과되었습니다";


            return msg;
        }

        if(classes.getAttCode() > 0)
        {
            if(duration.getSeconds() >= 20){
                // duration.getSeconds() >= 600 && duration.getSeconds() <= 1500 는 지각 이런 식으로 해도 될 듯
                msg = "지각";
                attendanceService.update2(takeClass.getUser().getUserId(), takeClassDto.getTakeId(), 2);
                return msg;
            }
            // Attendance 테이블에 채워넣기
            attendanceService.update2(takeClass.getUser().getUserId(), takeClassDto.getTakeId(), 1);

            msg = "출석 성공";

            return msg;
        }
        else
        {
            msg = "출석 실패";

            return msg;
        }
    }

    @PostMapping("/att/attlist")
    public List<AttendanceTestDto> getAttList(@RequestBody TakeClassDto takeClassDto){
        List<Attendance> attList = attendanceService.attUser(takeClassDto.getTakeId());
        List<AttendanceTestDto> AttendanceDtoList = new ArrayList<>();

        for(Attendance attendance : attList) {
            int attendanceOx = attendance.getAttendanceOx();
            LocalDateTime createdDate = attendance.getCreatedDate();
            LocalDate testDate = createdDate.toLocalDate();
            String testDateString = testDate.toString();


            AttendanceDtoList.add(new AttendanceTestDto(attendanceOx, testDateString));
            System.out.println("attendanceOx : " + attendanceOx + "  createdDate : " + testDateString);
        }


        return AttendanceDtoList;
    }
}
