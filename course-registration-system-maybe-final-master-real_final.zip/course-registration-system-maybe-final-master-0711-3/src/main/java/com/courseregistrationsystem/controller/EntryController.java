package com.courseregistrationsystem.controller;

import com.courseregistrationsystem.domain.Entry;
import com.courseregistrationsystem.domain.User;
import com.courseregistrationsystem.service.EntryService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
@RequiredArgsConstructor
@Slf4j
public class EntryController {

    private final EntryService entryService;

    @GetMapping("/entry/list")
    public String entryList(@AuthenticationPrincipal User user, Model model){
        List<Entry> entryList = entryService.findAll();

        model.addAttribute("entryList", entryList);

        return "entryList";
    }
}
