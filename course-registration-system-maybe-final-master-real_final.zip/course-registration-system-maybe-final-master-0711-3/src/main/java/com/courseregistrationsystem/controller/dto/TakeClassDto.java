package com.courseregistrationsystem.controller.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TakeClassDto {

    private Long takeId;
    private String courseName;

    public TakeClassDto(Long takeId, String courseName) {
        this.takeId = takeId;
        this.courseName = courseName;
    }
}
