package com.courseregistrationsystem.controller.dto;


import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Setter
@Getter
public class AttendanceTestDto {

    private int attendanceOx;
    private String createdDate;

    public AttendanceTestDto(int attendanceOx, String createdDate){
        this.attendanceOx = attendanceOx;
        this.createdDate = createdDate;
    }
}
