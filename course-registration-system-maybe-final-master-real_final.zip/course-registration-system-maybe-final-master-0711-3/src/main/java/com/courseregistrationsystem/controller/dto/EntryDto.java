package com.courseregistrationsystem.controller.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EntryDto {

    private String loginId;

    private int entryexit;

    public EntryDto(String loginId, int entryexit) {
        this.loginId = loginId;
        this.entryexit = entryexit;
    }
}
