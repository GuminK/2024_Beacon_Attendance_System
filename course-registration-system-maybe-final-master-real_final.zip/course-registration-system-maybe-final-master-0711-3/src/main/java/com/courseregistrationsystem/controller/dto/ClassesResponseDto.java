/*
package com.courseregistrationsystem.controller.dto;

import com.courseregistrationsystem.domain.Major;
import com.courseregistrationsystem.domain.TakeClass;
import com.courseregistrationsystem.domain.User;

import java.util.List;

public class ClassesResponseDto {

    private Long classId;
    private int classNumber;
    private int curStudentNum;
    private int maxStudentNum;
    private String professorName;
    private Major major;
    private List<TakeClass> takeClasses;

    public UserResponseDto(User entity) {
        this.userId = entity.getUserId();
        this.loginId = entity.getLoginId();
        this.username = entity.getUsername();
        this.email = entity.getEmail();
        this.phoneNumber = entity.getPhoneNumber();
        this.major = entity.getMajor();
        this.takeClasses = entity.getTakeClasses();
    }
}
*/