package com.courseregistrationsystem.controller;

import com.courseregistrationsystem.domain.User;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpSession;

@Controller
@RequiredArgsConstructor
@Slf4j
public class HomeController {

    private final HttpSession httpSession;

    @GetMapping(value = {"/", "/home"})
    public String home(@RequestParam(value="msg", required = false) String msg, Model model) {
        Object user = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        model.addAttribute("msg", msg);

        log.info("{}", user);

        if (user != "anonymousUser") {
            model.addAttribute("user", (User) user);
        }

        return "home";
    }
}
