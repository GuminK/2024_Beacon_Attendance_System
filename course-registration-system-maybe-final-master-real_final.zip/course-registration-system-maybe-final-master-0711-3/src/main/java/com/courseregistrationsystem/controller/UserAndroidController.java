package com.courseregistrationsystem.controller;

import com.courseregistrationsystem.controller.dto.EntryDto;
import com.courseregistrationsystem.controller.dto.UserLoginDto;
import com.courseregistrationsystem.controller.dto.UserResponseDto;
import com.courseregistrationsystem.controller.dto.UserSignUpDto;
import com.courseregistrationsystem.domain.User;
import com.courseregistrationsystem.repository.UserRepository;
import com.courseregistrationsystem.service.EntryService;
import com.courseregistrationsystem.service.UserAndroidService;
import com.courseregistrationsystem.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@Slf4j
public class UserAndroidController {

    private final UserRepository userRepository;
    private final UserService userService;
    private final UserAndroidService userAndroidService;
    private final EntryService entryService;

    @GetMapping("/user/list")
    public List<User> getAllUser() {
        return userService.findAll();
    }

    @PostMapping("/user/save")
    public void save(@RequestBody UserSignUpDto userSignUpDto) {
        userAndroidService.join(userSignUpDto);
    }

    @PostMapping("/user/login")
    public String login(@RequestBody UserLoginDto userLoginDto){
        String msg = userAndroidService.Login(userLoginDto);

        System.out.println("성공?");

        if(msg=="1") {
            return "success";
        }

        if(msg=="2") {
            System.out.println("실패~");
            return "fail";
        }

        System.out.println("실행은시켰음");

        return "success";
    }

    @PostMapping("/entry/save")
    public String EntrySave(@RequestBody EntryDto entryDto) {

        String loginId = entryDto.getLoginId();

        UserResponseDto userResponseDto = userAndroidService.findByLoginId(loginId);
        entryService.save(userResponseDto.getUserId(), entryDto.getEntryexit());

        return "success";
    }

    @PostMapping("/entry/update")
    public String EntryUpdate(@RequestBody EntryDto entryDto) {

        String loginId = entryDto.getLoginId();

        UserResponseDto userResponseDto = userAndroidService.findByLoginId(loginId);
        entryService.update(userResponseDto.getUserId(), entryDto.getEntryexit());

        return "success";
    }
}
