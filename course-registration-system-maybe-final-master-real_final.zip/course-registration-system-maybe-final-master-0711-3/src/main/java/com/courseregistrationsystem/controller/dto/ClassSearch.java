package com.courseregistrationsystem.controller.dto;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class ClassSearch {

    private Long majorId;
    private Long courseId;
}
