package com.courseregistrationsystem.controller;

import com.courseregistrationsystem.repository.UserRepository;
import com.courseregistrationsystem.service.AttendanceService;
import com.courseregistrationsystem.service.MajorService;
import com.courseregistrationsystem.service.UserService;
import com.courseregistrationsystem.controller.dto.UserResponseDto;
import com.courseregistrationsystem.controller.dto.UserSignUpDto;
import com.courseregistrationsystem.controller.dto.UserUpdateRequestDto;
import com.courseregistrationsystem.domain.Major;
import com.courseregistrationsystem.domain.User;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.courseregistrationsystem.domain.Role.PROFESSOR;

@Controller
@RequiredArgsConstructor
@Slf4j
public class UserController {

    private final UserService userService;
    private final MajorService majorService;
    private final AttendanceService attendanceService;
    private final UserRepository userRepository;

    @GetMapping("/login")
    public String login(Model model,
                        @RequestParam(value = "error", required = false) String error,
                        @RequestParam(value = "exception", required = false) String exception) {

        model.addAttribute("error", error);
        model.addAttribute("exception", exception);

        return "login";
    }

    @GetMapping("/signup")
    public String signup(Model model,
                         @RequestParam(value="msg", required = false) String msg) {
        List<Major> majors = majorService.findAll();

        model.addAttribute("signUpDto", new UserSignUpDto());
        model.addAttribute("majors", majors);
        model.addAttribute("msg", msg);
        return "signup";
    }

    @PostMapping("/signup")
    public String create(UserSignUpDto signUpDto, Model model) {
        try {
            userService.join(signUpDto);
        } catch (Exception e) {
            List<Major> majors = majorService.findAll();

            model.addAttribute("majors", majors);
            model.addAttribute("signUpDto", signUpDto);
            model.addAttribute("msg", e.getMessage());
            return "signup";
        }
        return "redirect:/";
    }

    @GetMapping("/myCourses")
    public String myCourseList(@AuthenticationPrincipal User user, Model model,
                               @RequestParam(value="msg", required = false) String msg) {
        UserResponseDto userResponseDto = userService.findById(user.getUserId());

        model.addAttribute("username", userResponseDto.getUsername());
        model.addAttribute("takeClasses", userResponseDto.getTakeClasses());
        model.addAttribute("msg", msg);

        return "myCourseList";
    }

    @GetMapping("/edit")
    public String update(@AuthenticationPrincipal User user, Model model,
                         @RequestParam(value="msg", required = false) String msg) {

        UserResponseDto userResponseDto = userService.findById(user.getUserId());
        model.addAttribute("userUpdateRequestDto", new UserUpdateRequestDto(userResponseDto));
        model.addAttribute("msg", msg);

        return "edit";
    }

    @PostMapping("/edit")
    public String userInfoUpdate(@AuthenticationPrincipal User user,
                                 UserUpdateRequestDto userUpdateRequestDto, Model model) {
        try {
            userService.update(user.getUserId(), userUpdateRequestDto);
        } catch (Exception e) {
            model.addAttribute("userUpdateRequestDto", userUpdateRequestDto);
            model.addAttribute("msg", e.getMessage());
            return "edit";
        }

        return "redirect:/";
    }

    @GetMapping("/Classes")
    public String ClassList(@AuthenticationPrincipal User user, Model model,
                            @RequestParam(value="msg", required = false) String msg) {
        UserResponseDto userResponseDto = userService.findById(user.getUserId());

        if(user.getRole()==PROFESSOR){

            model.addAttribute("username", userResponseDto.getUsername());
            model.addAttribute("proClass", userResponseDto.getHaveClasses());
            model.addAttribute("msg", msg);
            return "proClassList";

        }

        else {
            model.addAttribute("username", userResponseDto.getUsername());
            model.addAttribute("takeClasses", userResponseDto.getTakeClasses());
            model.addAttribute("msg", msg);
            return "myClassList";
        }
    }

    @GetMapping("/Attendance")
    public String AttendanceList(@AuthenticationPrincipal User user, Model model) {
        UserResponseDto userResponseDto = userService.findById(user.getUserId());

        if(user.getRole()==PROFESSOR){
            model.addAttribute("username", userResponseDto.getUsername());
            model.addAttribute("takeClasses", attendanceService.findAll());

            return "proAttendance";
        }

        else {
            model.addAttribute("username", userResponseDto.getUsername());
            model.addAttribute("takeClasses", userResponseDto.getTakeClasses());

            return "myAttendance";
        }
    }

    @GetMapping("/myAttendance/{id}")
    public String myAttendanceList(@PathVariable("id") Long takeId, Model model) {
        model.addAttribute("attendance",attendanceService.attUser(takeId));
        return "myAttendance";
    }
}
