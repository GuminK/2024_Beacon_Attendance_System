package com.courseregistrationsystem.controller;

import com.courseregistrationsystem.controller.dto.ClassSearch;
import com.courseregistrationsystem.controller.dto.ClassesSignUpDto;
import com.courseregistrationsystem.controller.dto.UserResponseDto;
import com.courseregistrationsystem.domain.Classes;
import com.courseregistrationsystem.domain.Course;
import com.courseregistrationsystem.domain.Major;
import com.courseregistrationsystem.domain.User;
import com.courseregistrationsystem.service.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequiredArgsConstructor
@Slf4j
public class TakeClassController {

    private final MajorService majorService;
    private final CourseService courseService;
    private final ClassesService classesService;
    private final TakeClassService takeClassService;
    private final UserService userService;
    private final AttendanceService attendanceService;

    @GetMapping("/register")
    public String courseRegistration(@ModelAttribute("classSearch") ClassSearch classSearch,
                                     @RequestParam(value  = "msg", required = false) String msg,
                                     Model model) {

        List<Classes> classes = classesService.findByCourse(classSearch.getCourseId());
        List<Course> courses = courseService.findByMajor(classSearch.getMajorId());
        List<Major> majors = majorService.findAll();

        model.addAttribute("classes", classes);
        model.addAttribute("courses", courses);
        model.addAttribute("majors", majors);

        model.addAttribute("msg", msg);

        return "courseRegistration";
    }

    @GetMapping("/register/{id}")
    public String courseRegister(@PathVariable("id") Long classId, @RequestParam(value  = "msg", required = false) String msg, @AuthenticationPrincipal User user, Model model) {
        model.addAttribute("msg", msg);
        try {
            takeClassService.save(user.getUserId(), classId);
        } catch (IllegalArgumentException e) {
            return "redirect:/home?msg=" + e.getMessage();
        }

        return "redirect:/home?msg=Success!";
    }

    @GetMapping("/cancel/{id}")
    public String courseCancel(@PathVariable("id") Long takeId) {
        attendanceService.attAllDelete(takeId);
        takeClassService.delete(takeId);

        return "redirect:/myCourses?msg=Success!";
    }


    @GetMapping("/create")
    public String courseCreate(User user, Model model, @RequestParam(value="msg", required = false) String msg) {

        List<Major> majors = majorService.findAll();

        model.addAttribute("classSignUpDto", new ClassesSignUpDto());
        model.addAttribute("majors", majors);
        model.addAttribute("msg", msg);

        return "courseCreate";
    }

    @PostMapping("/create")
    public String classCreate(@AuthenticationPrincipal User user, ClassesSignUpDto classSignUpDto, Model model) {
        try {
            Long courseId = takeClassService.join1(classSignUpDto);
            Long classId = takeClassService.join2(classSignUpDto, courseId);

            takeClassService.hsave(user.getUserId(), classId);

        } catch (Exception e) {
            List<Major> majors = majorService.findAll();

            model.addAttribute("classSignUpDto", new ClassesSignUpDto());
            model.addAttribute("majors", majors);
            model.addAttribute("msg", e.getMessage());

            return "courseCreate";
        }

        return "redirect:/";
    }

    @GetMapping("/delete/{id}")
    public String courseDelete(@PathVariable("id") Long haveId) {
        takeClassService.hdelete(haveId);

        return "redirect:/createList?msg=Success!";
    }
}
