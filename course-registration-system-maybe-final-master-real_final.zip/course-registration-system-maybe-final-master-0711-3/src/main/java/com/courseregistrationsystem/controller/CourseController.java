package com.courseregistrationsystem.controller;

import com.courseregistrationsystem.controller.dto.UserResponseDto;
import com.courseregistrationsystem.domain.*;
import com.courseregistrationsystem.repository.UserRepository;
import com.courseregistrationsystem.service.*;
import com.courseregistrationsystem.controller.dto.ClassSearch;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Controller
@RequiredArgsConstructor
@Slf4j
public class CourseController {

    private final CourseService courseService;
    private final MajorService majorService;
    private final UserService userService;
    private final TakeClassService takeClassService;
    private final HaveClassService haveClassService;

    @GetMapping("/courses")
    public String courseList(@ModelAttribute("classSearch") ClassSearch classSearch, Model model) {
        List<Course> courses = courseService.findByMajor(classSearch.getMajorId());
        List<Major> majors = majorService.findAll();

        model.addAttribute("courses", courses);
        model.addAttribute("majors", majors);

        return "courseList";
    }

    @GetMapping("/courses/{id}")
    public String classList(@PathVariable("id") Long courseId, Model model) {
        Course course = courseService.findById(courseId);

        model.addAttribute("classes", course.getClasses());

        return "classList";
    }

    @GetMapping("/createList")
    public String createList(@AuthenticationPrincipal User user, Model model,
                             @RequestParam(value="msg", required = false) String msg){
        UserResponseDto userResponseDto = userService.findById(user.getUserId());

        model.addAttribute("username", userResponseDto.getUsername());
        model.addAttribute("haveClasses", userResponseDto.getHaveClasses());
        model.addAttribute("msg", msg);

        return "createList";
    }

    @GetMapping("/detail/{id}")
    public String createDetail(@PathVariable("id") Long haveId, @AuthenticationPrincipal User user, Model model,
                               @RequestParam(value = "msg", required = false) String msg){

        model.addAttribute("userinfo", takeClassService.findByClass(haveId));

        return "detailList";
    }
}
