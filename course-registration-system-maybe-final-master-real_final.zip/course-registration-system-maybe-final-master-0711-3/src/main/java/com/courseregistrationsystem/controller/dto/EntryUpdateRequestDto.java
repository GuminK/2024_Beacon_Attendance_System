package com.courseregistrationsystem.controller.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class EntryUpdateRequestDto {

    private int entryexit;

    public EntryUpdateRequestDto(EntryDto entryDto) {
        this.entryexit = entryDto.getEntryexit();
    }
}
