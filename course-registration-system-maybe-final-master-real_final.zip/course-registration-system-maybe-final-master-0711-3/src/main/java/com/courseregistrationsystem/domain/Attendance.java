package com.courseregistrationsystem.domain;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Entity
@NoArgsConstructor
@Getter
@Setter
public class Attendance extends BaseTimeEntity{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long attendanceNum;

//    @Column(name = "attendance_date", nullable = false)
//    private String attendanceDate;

    @Column(name = "attendance_ox", nullable = false)
    private int attendanceOx;

    @ManyToOne(targetEntity = User.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne(targetEntity = Classes.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "class_id")
    private Classes classes;

    @OneToOne(targetEntity = TakeClass.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "take_id")
    private TakeClass takeClass;

    @Builder
    public Attendance(User user, Classes classes, TakeClass takeClass, int attendanceOx) {
        this.user = user;
        this.classes = classes;
        this.takeClass = takeClass;
//        this.attendanceDate = attendanceDate;
        this.attendanceOx = attendanceOx;
    }
}
