package com.courseregistrationsystem.domain;

import com.courseregistrationsystem.controller.dto.UserUpdateRequestDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Getter
@NoArgsConstructor
@Entity
public class User extends BaseTimeEntity implements UserDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(nullable = false)
    private String loginId;

    @Column(nullable = false)
    private String password;

    @Column(nullable = false)
    private String username;

    @ManyToOne(targetEntity = Major.class, fetch = FetchType.EAGER)
    @JoinColumn(name="major_id")
    private Major major;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Role role;

    @Column
    private String email;

    @Column
    private String phoneNumber;

    @OneToMany(mappedBy = "user")
    private List<TakeClass> takeClasses;

    @OneToMany(mappedBy = "professor")
    private List<HaveClass> haveClasses;

    @OneToMany(mappedBy = "user")
    private List<Attendance> attendances;

    @OneToMany(mappedBy = "user")
    private List<Entry> entrys;


    @Builder(builderClassName = "UserSignUpBuilder", builderMethodName = "signupBuilder")
    public User(String loginId, String password, String username, Major major, String email, String phoneNumber) {
        this.loginId = loginId;
        this.password = password;
        this.username = username;
        this.major = major;
        this.email = email;
        this.phoneNumber = phoneNumber;

        if(this.loginId.equals("professor")) {
            this.role = Role.PROFESSOR;
            this.haveClasses = new ArrayList<>();
            this.entrys = new ArrayList<>();
        }

        else {
            this.role = Role.STUDENT;
            this.takeClasses = new ArrayList<>();
            this.attendances = new ArrayList<>();
            this.entrys = new ArrayList<>();
        }
    }

    public void update(UserUpdateRequestDto requestDto) {
        this.email = requestDto.getEmail();
        this.phoneNumber = requestDto.getPhoneNumber();
    }

    /* 수강 신청 */
    public void registration(TakeClass takeClass) {
        this.takeClasses.add(takeClass);
    }

    /* 수강 취소 */
    public void cancel(TakeClass takeClass) {
        this.takeClasses.remove(takeClass);
    }

    public void delete(HaveClass haveClass) { this.haveClasses.remove(haveClass); }
    
    /* 강좌 개설
    public void createClass(Classes classes) { this.createClasses.add(classes); }
     */

    /* 강좌 삭제
    public void deleteClass(Classes classes) { this.createClasses.remove(classes); }
     */

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        List<GrantedAuthority> authorities = new ArrayList<>();
        authorities.add(new SimpleGrantedAuthority("ROLE_USER")); // 모든 사용자에게 기본적으로 USER 권한 부여

        if (this.role == Role.PROFESSOR) {
            authorities.add(new SimpleGrantedAuthority("ROLE_ADMIN")); // 교수일 경우 ADMIN 권한 추가
        }

        return authorities;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }
}
