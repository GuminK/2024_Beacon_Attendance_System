package com.courseregistrationsystem.domain;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.ColumnDefault;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@NoArgsConstructor
@Getter
public class Classes {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "class_id", nullable = false)
    private Long classId;

    @ManyToOne(targetEntity = Course.class, fetch = FetchType.LAZY)
    @JoinColumn(name="course_id")
    private Course course;

    @Column(nullable = false)
    private int classNumber;

    @Column(nullable = false)
    private String professorName;

    @Column(nullable = false)
    private int maxStudentNum;

    @Column(nullable = false)
    private int curStudentNum;

    @Column
    private LocalDateTime checkTime;

    @ColumnDefault("0")
    private int AttCode;

    public void setAttCode(int attCode) {
        AttCode = attCode;
    }
    public void setCheckTime(LocalDateTime checkTime){ this.checkTime = checkTime;}

    @Builder
    public Classes(Course course, int classNumber, String professorName, int maxStudentNum, int curStudentNum, LocalDateTime checkTime) {
        this.course = course;
        this.classNumber = classNumber;
        this.professorName = professorName;
        this.maxStudentNum = maxStudentNum;
        this.curStudentNum = curStudentNum;
        this.checkTime = checkTime;
    }

    //== 수강 신청 ==//
    public void registration() {
        this.curStudentNum++;
    }

    //== 수강 취소 ==//
    public void cancel() {
        this.curStudentNum--;
    }

    //== 수강 인원 확인 ==//
    public boolean isFull() {
        return curStudentNum >= maxStudentNum;
    }

    public Long getClassId() {
        return classId;
    }
}
