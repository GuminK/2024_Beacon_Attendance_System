package com.courseregistrationsystem.domain;

import com.courseregistrationsystem.controller.dto.EntryDto;
import com.fasterxml.jackson.databind.ser.Serializers;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@NoArgsConstructor
@Entity
public class Entry extends BaseTimeEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "entry_id", nullable = false)
    private Long entryId;

    @ManyToOne(targetEntity = User.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private User user;

    @Column(name = "entry_exit", nullable = true)
    private int entryexit;

    @Builder
    public Entry(User user, int entryexit) {
        this.user = user;
        this.entryexit = entryexit;
    }

    public void update(int entryexit) {
        this.entryexit = entryexit;
    }
}
