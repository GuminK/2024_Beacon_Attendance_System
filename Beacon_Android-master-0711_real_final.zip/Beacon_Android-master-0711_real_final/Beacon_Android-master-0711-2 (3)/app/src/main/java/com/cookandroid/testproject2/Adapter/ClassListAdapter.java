package com.cookandroid.testproject2.Adapter;


import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


import com.cookandroid.testproject2.AttendanceList;
import com.cookandroid.testproject2.ClassList;
import com.cookandroid.testproject2.R;
import com.cookandroid.testproject2.Retrofit.RetrofitClient;
import com.cookandroid.testproject2.Retrofit.UserRetrofitInterface;
import com.cookandroid.testproject2.domain.dto.TakeClassDto;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ClassListAdapter extends BaseAdapter {

    Context context;
    ArrayList<TakeClassDto> list;
    LayoutInflater inflater;

    private SharedPreferences preferences;





    public ClassListAdapter(Context context, ArrayList<TakeClassDto> list){
        this.context = context;
        this.list = list;
        this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    public void addDTO(TakeClassDto dto){
        list.add(dto);
    }

    public void delDTO(int position){
        list.remove(position);
    }

    public void removeDTOs(){
        list.clear();
    }

    @Override
    public int getCount(){
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position){
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        preferences = context.getSharedPreferences("BeaconTF", Context.MODE_PRIVATE);

        String msg = preferences.getString("BeaconUsed","");





        RetrofitClient retrofitClient = new RetrofitClient();
        UserRetrofitInterface userRetrofitInterface = retrofitClient.getRetrofit().create(UserRetrofitInterface.class);

        ClassViewHolder viewHolder;

        if(convertView == null) {
            convertView = inflater.inflate(R.layout.classview, parent, false);
            viewHolder = new ClassViewHolder();
            viewHolder.ClassNameView = convertView.findViewById(R.id.className);
            viewHolder.btn_attCheckButton = convertView.findViewById(R.id.attCheckButton);

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ClassViewHolder) convertView.getTag();
        }

        TakeClassDto dto = list.get(position);
        String className = dto.getCourseName();
        Long takeId = dto.getTakeId();

        viewHolder.ClassNameView.setText(className);
        // BeaconUsed가 활성화 되면 출석 버튼 활성화
        if(preferences.getString("BeaconUsed","").length() != 0 ){
            System.out.println("BeaconUsed = true");
            viewHolder.btn_attCheckButton.setEnabled(true);

        }
        System.out.println("BeaconUsed = " + preferences.getString("BeaconUsed",""));
//        System.out.println("BeaconUsed Test");

        viewHolder.ClassNameView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, AttendanceList.class);
                intent.putExtra("takeId", list.get(position).getTakeId());
                intent.putExtra("courseName", list.get(position).getCourseName());
                context.startActivity(intent);


            }
        });


        viewHolder.btn_attCheckButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                userRetrofitInterface.checkAtt(list.get(position)) // TakeClassDto 통으로 넘김
                        .enqueue(new Callback<String>() {
                            @Override
                            public void onResponse(Call<String> call, Response<String> response) {
                                if (response.isSuccessful()) {
                                    String msg = response.body();
                                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
                                }

                                else {
                                    System.out.println("response.message: " + response.message());
                                }
                            }

                            @Override
                            public void onFailure(Call<String> call, Throwable t) {
                                t.printStackTrace();
                            }
                        });

            }
        });

        return convertView;
    }

    public class ClassViewHolder {
        public TextView ClassNameView;
        public Button btn_attCheckButton;
    }

}
