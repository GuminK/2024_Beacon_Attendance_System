package com.cookandroid.testproject2.domain.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EntryDto {

    private String loginId;

    private int entryexit;

    public EntryDto(String loginId, int entryexit) {
        this.loginId = loginId;
        this.entryexit = entryexit;
    }

    public EntryDto() {

    }


    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }

    public int getEntryexit() {
        return entryexit;
    }

    public void setEntryexit(int entryexit) {
        this.entryexit = entryexit;
    }
}
