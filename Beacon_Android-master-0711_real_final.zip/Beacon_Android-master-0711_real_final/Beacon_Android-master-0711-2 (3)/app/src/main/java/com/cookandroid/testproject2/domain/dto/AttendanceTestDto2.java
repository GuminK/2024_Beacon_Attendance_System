package com.cookandroid.testproject2.domain.dto;

public class AttendanceTestDto2 {
    private String attendanceOx;

    private String createdDate;

    public AttendanceTestDto2(String attendanceOx, String createdDate){
        this.attendanceOx = attendanceOx;
        this.createdDate = createdDate;
    }


    public String getAttendanceOx() {
        return attendanceOx;
    }

    public void setAttendanceOx(String attendanceOx) {
        this.attendanceOx = attendanceOx;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }
}
