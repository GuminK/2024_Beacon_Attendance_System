package com.cookandroid.testproject2.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.cookandroid.testproject2.AttendanceList;
import com.cookandroid.testproject2.R;
import com.cookandroid.testproject2.Retrofit.RetrofitClient;
import com.cookandroid.testproject2.Retrofit.UserRetrofitInterface;
import com.cookandroid.testproject2.domain.dto.AttendanceTestDto;
import com.cookandroid.testproject2.domain.dto.TakeClassDto;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AttendanceListAdapter extends BaseAdapter {
    Context context;
    ArrayList<AttendanceTestDto> list;
    LayoutInflater inflater;

    public AttendanceListAdapter(Context context, ArrayList<AttendanceTestDto> list){
        this.context = context;
        this.list = list;
        this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    public void addDTO(AttendanceTestDto dto){
        list.add(dto);
    }

    public void delDTO(int position){
        list.remove(position);
    }

    public void removeDTOs(){
        list.clear();
    }

    @Override
    public int getCount(){
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position){
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {





        RetrofitClient retrofitClient = new RetrofitClient();
        UserRetrofitInterface userRetrofitInterface = retrofitClient.getRetrofit().create(UserRetrofitInterface.class);

        AttendanceListAdapter.AttendanceViewHolder viewHolder;

        if(convertView == null) {
            convertView = inflater.inflate(R.layout.attendanceview, parent, false);
            viewHolder = new AttendanceListAdapter.AttendanceViewHolder();
            viewHolder.AttendanceDateView = convertView.findViewById(R.id.AttendanceDate);
            viewHolder.AttendanceCheckView = convertView.findViewById(R.id.AttendanceCheck);

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (AttendanceListAdapter.AttendanceViewHolder) convertView.getTag();
        }

        AttendanceTestDto dto = list.get(position);
        String Date = dto.getCreatedDate();
        int Check = dto.getAttendanceOx();



        viewHolder.AttendanceDateView.setText(Date);
        if (Check==0){
            viewHolder.AttendanceCheckView.setText("결석");
        }
        else if(Check==1){
            viewHolder.AttendanceCheckView.setText("출석");
        }
        else if(Check==2){
            viewHolder.AttendanceCheckView.setText("지각");
        }
        else if(Check==3){
            viewHolder.AttendanceCheckView.setText("결석");
        }
        else viewHolder.AttendanceCheckView.setText("error");




        return convertView;
    }

    public class AttendanceViewHolder {
        public TextView AttendanceDateView;
        public TextView AttendanceCheckView;
    }
}
