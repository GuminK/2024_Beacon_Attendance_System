package com.cookandroid.testproject2;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.cookandroid.testproject2.Adapter.ClassListAdapter;
import com.cookandroid.testproject2.Retrofit.RetrofitClient;
import com.cookandroid.testproject2.Retrofit.UserRetrofitInterface;
import com.cookandroid.testproject2.domain.dto.EntryDto;
import com.cookandroid.testproject2.domain.dto.TakeClassDto;

import org.altbeacon.beacon.Beacon;
import org.altbeacon.beacon.BeaconManager;
import org.altbeacon.beacon.BeaconParser;
import org.altbeacon.beacon.MonitorNotifier;
import org.altbeacon.beacon.RangeNotifier;
import org.altbeacon.beacon.Region;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ClassList extends AppCompatActivity implements RangeNotifier {
    ListView listView;

    String test_msg;

    ArrayList<TakeClassDto> takeClassList;

    ClassListAdapter adapter;
    String entryId = "";
    String uuid = "";

    String uuid1 = "e2c56db5-dffb-48d2-b060-d0f5a71096e0"; // g

    private BeaconManager mBeaconManager;

    String beaconLayout = "m:2-3=0215,i:4-19,i:20-21,i:22-23,p:24-24";

    private String TAG ="ClassList";

    private SharedPreferences preferences;



    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.classlist);

        preferences = getSharedPreferences("UserInfo", MODE_PRIVATE);
        test_msg = preferences.getString("user_id","");

        RetrofitClient retrofitClient = new RetrofitClient();
        UserRetrofitInterface userRetrofitInterface = retrofitClient.getRetrofit().create(UserRetrofitInterface.class);

        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(ClassList.this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN}, 1);
        }

        startBeaconMonitoring();

        takeClassList = new ArrayList<>();

        adapter = new ClassListAdapter(ClassList.this, takeClassList);

        listView = findViewById(R.id.classListView);
        listView.setAdapter(adapter);

        userRetrofitInterface.getClass(test_msg)
                .enqueue(new Callback<List<TakeClassDto>>() {
                    @Override
                    public void onResponse(Call<List<TakeClassDto>> call, Response<List<TakeClassDto>> response) {
                        if (response.isSuccessful()) {
                            List<TakeClassDto> takeClassDto = response.body();

                            for (TakeClassDto takeClass : takeClassDto) {
                                adapter.addDTO(takeClass);
                                adapter.notifyDataSetChanged();
                            }
                        }

                        else {
                            System.out.println("Request failed: " + response.message());
                        }
                    }

                    @Override
                    public void onFailure(Call<List<TakeClassDto>> call, Throwable t) {
                        t.printStackTrace();
                    }
                });

        adapter.notifyDataSetChanged();

    }

    private void startBeaconMonitoring() {
        RetrofitClient retrofitClient = new RetrofitClient();
        UserRetrofitInterface userRetrofitInterface = retrofitClient.getRetrofit().create(UserRetrofitInterface.class);

//        String test_msg;
//        test_msg = preferences.getString("user_id","");

        EntryDto entryDto = new EntryDto();
        entryDto.setLoginId(test_msg);
        entryDto.setEntryexit(0);

        mBeaconManager = BeaconManager.getInstanceForApplication(this);
        mBeaconManager.getBeaconParsers().add(new BeaconParser().setBeaconLayout(beaconLayout));

        mBeaconManager.addMonitorNotifier(new MonitorNotifier() {
            @Override
            public void didEnterRegion(Region region) {
                Handler handler = new Handler(Looper.getMainLooper());
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run()
                    {
                        showToast( "didEnterRegion - 비콘 연결됨");
                        preferences = getSharedPreferences("BeaconTF", MODE_PRIVATE);
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.putString("BeaconUsed","True");
                        editor.commit();
                        adapter.notifyDataSetChanged();

                    }
                }, 0);
                Log.i(TAG, "I just saw an beacon for the first time!");
            }

            @Override
            public void didExitRegion(Region region) {
                Handler handler = new Handler(Looper.getMainLooper());
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run()
                    {
                        showToast("didExitRegion - 비콘 연결 끊김");

                    }
                }, 0);
                Log.i(TAG, "I no longer see an beacon");
                //textView.setText("Beacon disconnected");
            }

            @Override
            public void didDetermineStateForRegion(int i, Region region) {
                Log.i(TAG, "I have just switched from seeing/not seeing beacons: " + i);
            }
        });
        mBeaconManager.addRangeNotifier(this);

        try {
            mBeaconManager.startMonitoring(new Region("test", null,null, null));
            mBeaconManager.startRangingBeacons(new Region("test", null, null, null));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mBeaconManager != null) {
            try {
                mBeaconManager.stopMonitoring(new Region("test", null,null, null));
                mBeaconManager.stopRangingBeacons(new Region("test", null, null, null));
            } catch (Exception e) {
                e.printStackTrace();
            }

            mBeaconManager.removeAllMonitorNotifiers();
            mBeaconManager.removeAllRangeNotifiers();
        }
    }

    @Override
    public void didRangeBeaconsInRegion(Collection<Beacon> beacons, Region region) {



        if (beacons.size() > 0) {
            uuid = beacons.iterator().next().getId1().toString();
            Log.i(TAG, "The first beacon I see is about " + ((Beacon) beacons.iterator().next()).getDistance() + " meters away.");
            Log.i(TAG, "uuid : " + uuid);


            if(((Beacon) beacons.iterator().next()).getDistance()>2){

                RetrofitClient retrofitClient = new RetrofitClient();
                UserRetrofitInterface userRetrofitInterface = retrofitClient.getRetrofit().create(UserRetrofitInterface.class);

//                String test_msg;
//                test_msg = preferences.getString("user_id","");

                EntryDto entryDto = new EntryDto();
                entryDto.setLoginId(test_msg);
                entryDto.setEntryexit(1);
                System.out.println("ㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁ");
                System.out.println("entryDto.getLoginId : " + entryDto.getLoginId());

                userRetrofitInterface.EntryUpdate(entryDto)
                        .enqueue(new Callback<String>() {
                            @Override
                            public void onResponse(Call<String> call, Response<String> response) {
                                if (response.isSuccessful()) {
                                    System.out.println("------------------------------");
                                    System.out.println(response.body());

                                }
                            }

                            @Override
                            public void onFailure(Call<String> call, Throwable t) {
                                showToast(t.getMessage());
                                Log.e(TAG, t.getMessage());
                            }
                        });
                onDestroy();
                showToast("강의실 시스템과 연결이 끊겼습니다.");
            }

        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 1){
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED){
                showToast("Permission Granted");
            }
            else {
                showToast("Permission Denied");
            }
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();


        Intent intent = new Intent(ClassList.this, logined_home.class);
        startActivity(intent);
        finish();
    }

    //Toast message function
    private void showToast (String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }
}
