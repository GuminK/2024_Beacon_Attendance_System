/*package com.cookandroid.testproject2.domain;

import lombok.Getter;

@Getter
public class Major {
    private Long majorId;
    private String majorName;

    // 생성자
    public Major(String majorName) {
        this.majorName = majorName;
    }
}

*/