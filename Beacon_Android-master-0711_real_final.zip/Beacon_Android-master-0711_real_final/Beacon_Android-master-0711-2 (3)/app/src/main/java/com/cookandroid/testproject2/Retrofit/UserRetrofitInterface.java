package com.cookandroid.testproject2.Retrofit;

import com.cookandroid.testproject2.domain.Attendance;
import com.cookandroid.testproject2.domain.User;
import com.cookandroid.testproject2.domain.dto.AttendanceTestDto;
import com.cookandroid.testproject2.domain.dto.EntryDto;
import com.cookandroid.testproject2.domain.dto.TakeClassDto;
import com.cookandroid.testproject2.domain.dto.UserDTO;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.HTTP;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface UserRetrofitInterface {

    //@GET("user-test")
    //Call<UserDTO> getUser();

    @GET("/user/list")
    Call<List<User>> getAllUser();

    @POST("/user/save")
    Call<User> save(@Body User user);

    @POST("/login/action")
    Call<Void> login(@Body UserDTO userDTO);

    @POST("/user/login")
    Call<String> testLogin(@Body UserDTO userDTO);


    @POST("/att/list")
        //@HTTP(method = "GET", path = "/att/list/{loginId}", hasBody = true)
    Call<List<TakeClassDto>> getClass(@Body String loginId);

    @POST("/att/checkTest")
    Call<String> checkAtt(@Body TakeClassDto takeClassDto);

    @POST("/att/attlist")
    Call<List<AttendanceTestDto>> getAttList(@Body TakeClassDto takeClassDto);


    @POST("/entry/save")
    Call<String> EntrySave(@Body EntryDto entryDto);

    @POST("/entry/update")
    Call<String> EntryUpdate(@Body EntryDto entryDto);



//    @GET("/signup")
//    Call<List<Major>> getMajors();

    //@POST("/signup")
    //Call<SignUpResponse> saveUser(@Body User user);
}