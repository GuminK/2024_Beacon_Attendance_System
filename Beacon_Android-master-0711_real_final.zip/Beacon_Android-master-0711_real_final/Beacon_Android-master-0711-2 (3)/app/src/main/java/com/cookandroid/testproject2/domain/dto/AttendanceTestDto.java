package com.cookandroid.testproject2.domain.dto;

import com.google.gson.annotations.SerializedName;

import java.time.LocalDate;
import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

public class AttendanceTestDto {
    private int attendanceOx;

    private String createdDate;

    public AttendanceTestDto(int attendanceOx, String createdDate){
        this.attendanceOx = attendanceOx;
        this.createdDate = createdDate;
    }


    public int getAttendanceOx() {
        return attendanceOx;
    }

    public void setAttendanceOx(int attendanceOx) {
        this.attendanceOx = attendanceOx;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }
}
