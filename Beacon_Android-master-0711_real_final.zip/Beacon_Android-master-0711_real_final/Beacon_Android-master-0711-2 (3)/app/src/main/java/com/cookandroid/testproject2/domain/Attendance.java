package com.cookandroid.testproject2.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Attendance {

    private Long attendanceNum;
    private int attendanceOx;

    private User user;

    public Attendance(){
        this.attendanceNum = attendanceNum;
        this.attendanceOx = attendanceOx;
        this.user = user;
    }



}
