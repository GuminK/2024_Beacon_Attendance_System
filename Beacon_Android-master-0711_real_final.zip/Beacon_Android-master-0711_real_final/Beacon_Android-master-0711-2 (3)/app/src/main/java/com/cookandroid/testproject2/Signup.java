package com.cookandroid.testproject2;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.cookandroid.testproject2.Retrofit.RetrofitClient;
import com.cookandroid.testproject2.Retrofit.UserRetrofitInterface;
import com.cookandroid.testproject2.domain.dto.SignUpResponse;
import com.cookandroid.testproject2.domain.User;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Signup extends AppCompatActivity {

    Button btn_cancel, SignUp;

    EditText Username, LoginId, Password, PasswordConfirm, Email, PhoneNumber, Major;

    Spinner spinner;

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        Intent intent = new Intent(Signup.this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup);

        btn_cancel = findViewById(R.id.btn_cancel);
        SignUp = findViewById(R.id.SignUp);

        Username = findViewById(R.id.Username);
        LoginId = findViewById(R.id.LoginId);
        Password = findViewById(R.id.Password);
        PasswordConfirm = findViewById(R.id.PasswordConfirm);
        Email = findViewById(R.id.Email);
        PhoneNumber = findViewById(R.id.PhoneNumber);
        Major = findViewById(R.id.Major);

        //Call<List<Major>> callM = userRetrofitInterface.getMajors();

        RetrofitClient retrofitClient = new RetrofitClient();
        UserRetrofitInterface userRetrofitInterface = retrofitClient.getRetrofit().create(UserRetrofitInterface.class);

        SignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String UsernameText = Username.getText().toString();
                String LoginIdText = LoginId.getText().toString();
                String PasswordText = Password.getText().toString();
                String PasswordConfirmText = PasswordConfirm.getText().toString();
                String EmailText = Email.getText().toString();
                String PhoneNumberText = PhoneNumber.getText().toString();
                String MajorText = Major.getText().toString();

                Long MajorLong = Long.parseLong(MajorText);

                User user = new User();
                user.setUsername(UsernameText);
                user.setLoginId(LoginIdText);
                user.setPassword(PasswordText);
                user.setPasswordConfirm(PasswordConfirmText);
                user.setEmail(EmailText);
                user.setPhoneNumber(PhoneNumberText);
                user.setMajorId(MajorLong);

                userRetrofitInterface.save(user)
                        .enqueue(new Callback<User>() {
                            @Override
                            public void onResponse(Call<User> call, Response<User> response) {
                                Toast.makeText(Signup.this, "Success!!", Toast.LENGTH_SHORT).show();
                            }

                            @Override
                            public void onFailure(Call<User> call, Throwable t) {
                                Toast.makeText(Signup.this, "Failed!!", Toast.LENGTH_SHORT).show();
                                Logger.getLogger(Signup.class.getName()).log(Level.SEVERE, "Error occurred", t);
                            }
                        });
            }
        });

        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Signup.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
