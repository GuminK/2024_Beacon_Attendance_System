package com.cookandroid.testproject2.domain.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TakeClassDto {

    private Long takeId;

    private String courseName;

    public TakeClassDto(Long takeId, String courseName){
        this.takeId = takeId;
        this.courseName = courseName;
    }
    public TakeClassDto(){

    }


    public Long getTakeId() {
        return takeId;
    }

    public void setTakeId(Long takeId) {
        this.takeId = takeId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }
}
