package com.cookandroid.testproject2;

import android.annotation.SuppressLint;
import android.os.Bundle;

import com.cookandroid.testproject2.Retrofit.RetrofitClient;
import com.cookandroid.testproject2.Retrofit.UserRetrofitInterface;
import com.cookandroid.testproject2.domain.User;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class UserList extends AppCompatActivity {

    Call<User> call;
    TextView textView;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.textView);

        RetrofitClient retrofitClient = new RetrofitClient();
        UserRetrofitInterface userRetrofitInterface = retrofitClient.getRetrofit().create(UserRetrofitInterface.class);
        Call<List<User>> call = userRetrofitInterface.getAllUser();

        call.enqueue(new Callback<List<User>>() {
            @Override
            public void onResponse(Call<List<User>> call, Response<List<User>> response) {
                if (!response.isSuccessful()) {
                    textView.setText("Code: " + response.code());
                    return;
                }
                List<User> users = response.body();
                for (User user : users) {
                    String content = "";
                    content += "ID: " + user.getLoginId() + "\n";
                    content += "Title: " + user.getUsername() + "\n\n";
                    textView.append(content);
                }
            }

            @Override
            public void onFailure(Call<List<User>> call, Throwable t) {
                textView.setText(t.getMessage());
            }
        });
    }
}
