/*package com.cookandroid.testproject2.Adapter;

import android.view.View;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MajorHolder extends RecyclerView.ViewHolder {

    Spinner spinner;

    public MajorHolder(@NonNull View itemView) {
        super(itemView);
        id = itemView.findViewById(R.id.)
    }
}
*/