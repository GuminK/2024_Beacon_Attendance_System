package com.cookandroid.testproject2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.cookandroid.testproject2.Adapter.AttendanceListAdapter;
import com.cookandroid.testproject2.Retrofit.RetrofitClient;
import com.cookandroid.testproject2.Retrofit.UserRetrofitInterface;
import com.cookandroid.testproject2.domain.Attendance;
import com.cookandroid.testproject2.domain.dto.AttendanceTestDto;
import com.cookandroid.testproject2.domain.dto.TakeClassDto;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AttendanceList extends AppCompatActivity {

    TextView textView;

    //   ---------------------------------------------

    ListView listView;

    ArrayList<AttendanceTestDto> attendanceList;

    AttendanceListAdapter adapter;



    @Override
    public void onBackPressed() {
        super.onBackPressed();

        Intent intent = new Intent(AttendanceList.this, ClassList.class);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.attendancelist);

        Intent thisIntent = getIntent();

        textView = findViewById(R.id.attendancelistTextView);

        Long test = thisIntent.getLongExtra("takeId", 1L);
        String takeIdString = test.toString();
        String courseName = thisIntent.getStringExtra("courseName");

        textView.setText("강의 이름 : " + courseName);
        TakeClassDto takeClassDto = new TakeClassDto(test, courseName);

        RetrofitClient retrofitClient = new RetrofitClient();
        UserRetrofitInterface userRetrofitInterface = retrofitClient.getRetrofit().create(UserRetrofitInterface.class);

        // --------------------------------------------------------

        attendanceList = new ArrayList<>();

        adapter = new AttendanceListAdapter(AttendanceList.this, attendanceList);

        listView = findViewById(R.id.attendanceListView);
        listView.setAdapter(adapter);

        userRetrofitInterface.getAttList(takeClassDto)
                .enqueue(new Callback<List<AttendanceTestDto>>() {
                    @Override
                    public void onResponse(Call<List<AttendanceTestDto>> call, Response<List<AttendanceTestDto>> response) {
                        if (response.isSuccessful()) {
                            List<AttendanceTestDto> AttendanceDtoList = response.body();
                            for (AttendanceTestDto attendanceDto : AttendanceDtoList) {
//                                String attChType;
//                                if(attendanceDto.getAttendanceOx()==0) attChType = "결석";
//                                else if (attendanceDto.getAttendanceOx()==1) attChType = "출석";
//                                else attChType = "지각";
//                                String testString = "\n" + attendanceDto.getCreatedDate() + "  " + attChType;
//                                System.out.println(attendanceDto);
//                                textView.append(testString);

                                adapter.addDTO(attendanceDto);
                                adapter.notifyDataSetChanged();

                            }

                        }
                    }

                    @Override
                    public void onFailure(Call<List<AttendanceTestDto>> call, Throwable throwable) {
                        showToast("getAttList실패");
                        System.out.println("---------------------");
                        throwable.printStackTrace();
                        System.out.println("---------------------");
                    }
                });

        adapter.notifyDataSetChanged();






    }

    private void showToast (String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }
}
