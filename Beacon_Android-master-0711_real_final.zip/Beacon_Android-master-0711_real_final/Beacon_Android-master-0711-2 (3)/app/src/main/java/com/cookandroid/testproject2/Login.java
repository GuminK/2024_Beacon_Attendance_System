package com.cookandroid.testproject2;

import static android.content.ContentValues.TAG;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.cookandroid.testproject2.Retrofit.RetrofitClient;
import com.cookandroid.testproject2.Retrofit.UserRetrofitInterface;
import com.cookandroid.testproject2.domain.dto.UserDTO;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Login extends AppCompatActivity {

    Button btn_cancel, btn_login;

    EditText LoginId, Password;


    private SharedPreferences preferences;
    @Override
    public void onBackPressed() {
        super.onBackPressed();

        Intent intent = new Intent(Login.this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        btn_cancel = findViewById(R.id.btn_cancel);
        btn_login = findViewById(R.id.btn_login);

        LoginId = findViewById(R.id.LoginId);
        Password = findViewById(R.id.Password);

        //Call<List<Major>> callM = userRetrofitInterface.getMajors();

        RetrofitClient retrofitClient = new RetrofitClient();
        UserRetrofitInterface userRetrofitInterface = retrofitClient.getRetrofit().create(UserRetrofitInterface.class);


        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String LoginIdText = LoginId.getText().toString();
                String PasswordText = Password.getText().toString();

                UserDTO userDTO = new UserDTO();
                userDTO.setLoginId(LoginIdText);
                userDTO.setPassword(PasswordText);

                preferences = getSharedPreferences("UserInfo", MODE_PRIVATE);

                userRetrofitInterface.testLogin(userDTO)
                        .enqueue(new Callback<String>() {
                            @Override
                            public void onResponse(Call<String> call, Response<String> response) {
                                if (response.isSuccessful()) {

                                    String msg = response.body();
//                                    if(msg=="success"){
//                                        Toast.makeText(Login.this, "msg==1 success~~!!", Toast.LENGTH_SHORT).show();
//                                    }
                                    Toast.makeText(Login.this, msg, Toast.LENGTH_SHORT).show(); // 성공하면 success, 실패하면 fail

                                    if(msg.equals("success")){
                                        SharedPreferences.Editor editor = preferences.edit();
                                        editor.putString("user_id",LoginIdText);
                                        editor.commit();
                                        Log.d(TAG, "Commit successful");
                                        Log.d(TAG, msg);
                                        Log.d(TAG, "Login successful");
                                        // 로그인 성공 시 필요한 작업 수행

//                                    Toast.makeText(Login.this, "Success!!", Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(Login.this, logined_home.class);
                                        startActivity(intent);
                                        finish();
                                    }

                                } else {
                                    Log.d(TAG, "Login failed");
                                    // 로그인 실패 시 필요한 작업 수행

                                    Toast.makeText(Login.this, "Failed!", Toast.LENGTH_SHORT).show();
                                }
                            }

                            @Override
                            public void onFailure(Call<String> call, Throwable t) {
                                Log.e(TAG, "Login request failed: " + t.getMessage());
                                Toast.makeText(Login.this, "Failed!!", Toast.LENGTH_SHORT).show();
                            }
                        });




//                userRetrofitInterface.login(userDTO)
//                        .enqueue(new Callback<Void>() {
//                            @Override
//                            public void onResponse(Call<Void> call, Response<Void> response) {
//                                if (response.isSuccessful()) {
//                                    Log.d(TAG, "Login successful");
//                                    // 로그인 성공 시 필요한 작업 수행
//
//                                    Toast.makeText(Login.this, "Success!!", Toast.LENGTH_SHORT).show();
//                                    Intent intent = new Intent(Login.this, MainActivity.class);
//                                    startActivity(intent);
//                                    finish();
//
//                                } else {
//                                    Log.d(TAG, "Login failed");
//                                    // 로그인 실패 시 필요한 작업 수행
//
//                                    Toast.makeText(Login.this, "Failed!", Toast.LENGTH_SHORT).show();
//                                }
//                            }
//
//                            @Override
//                            public void onFailure(Call<Void> call, Throwable t) {
//                                Log.e(TAG, "Login request failed: " + t.getMessage());
//                                Toast.makeText(Login.this, "Failed!!", Toast.LENGTH_SHORT).show();
//                            }
//                        });
            }
        });

        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Login.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
