package com.cookandroid.testproject2;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.cookandroid.testproject2.Retrofit.RetrofitClient;
import com.cookandroid.testproject2.Retrofit.UserRetrofitInterface;
import com.cookandroid.testproject2.domain.User;
import com.cookandroid.testproject2.domain.dto.TakeClassDto;

import org.altbeacon.beacon.Beacon;
import org.altbeacon.beacon.BeaconManager;
import org.altbeacon.beacon.BeaconParser;
import org.altbeacon.beacon.MonitorNotifier;
import org.altbeacon.beacon.RangeNotifier;
import org.altbeacon.beacon.Region;

import java.util.Collection;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Bluetooth extends AppCompatActivity implements RangeNotifier {

    Button btn_scanStart, btn_back, btn_check;
    TextView text_state;

    private BeaconManager mBeaconManager;

    private String TAG ="bluetooth";

    private SharedPreferences preferences;

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        Intent intent = new Intent(Bluetooth.this, logined_home.class);
        startActivity(intent);
        finish();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bluetooth);

        btn_scanStart = findViewById(R.id.btn_scanStart);
        btn_back = findViewById(R.id.btn_back);
        btn_check = findViewById(R.id.btn_check);
        text_state = findViewById(R.id.text_state);

        RetrofitClient retrofitClient = new RetrofitClient();
        UserRetrofitInterface userRetrofitInterface = retrofitClient.getRetrofit().create(UserRetrofitInterface.class);

        preferences = getSharedPreferences("UserInfo", MODE_PRIVATE);

        String test_msg;
        test_msg = preferences.getString("user_id","");

        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(Bluetooth.this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN}, 1);
        }

        btn_scanStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startBeaconMonitoring();
                text_state.setText("비콘 스캔중");

            }
        });

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Bluetooth.this, logined_home.class);
                startActivity(intent);
                finish();
            }
        });

        btn_check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Bluetooth.this, ClassList.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void startBeaconMonitoring() {
        mBeaconManager = BeaconManager.getInstanceForApplication(this);
        mBeaconManager.getBeaconParsers().add(new BeaconParser().setBeaconLayout("m:2-3=0215,i:4-19,i:20-21,i:22-23,p:24-24"));

        RetrofitClient retrofitClient = new RetrofitClient();
        UserRetrofitInterface userRetrofitInterface = retrofitClient.getRetrofit().create(UserRetrofitInterface.class);

        preferences = getSharedPreferences("UserInfo", MODE_PRIVATE);

        String test_msg;
        test_msg = preferences.getString("user_id","");

        mBeaconManager.addMonitorNotifier(new MonitorNotifier() {
            @Override
            public void didEnterRegion(Region region) {
                Handler handler = new Handler(Looper.getMainLooper());
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run()
                    {
                        showToast( "didEnterRegion - 비콘 연결됨");
                        text_state.setText("비콘 연결됨");

                        btn_check.setEnabled(true);
                    }
                }, 0);
                Log.i(TAG, "I just saw an beacon for the first time!");
            }

            @Override
            public void didExitRegion(Region region) {
                Handler handler = new Handler(Looper.getMainLooper());
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run()
                    {
                        showToast("didExitRegion - 비콘 연결 끊김");
                    }
                }, 0);
                Log.i(TAG, "I no longer see an beacon");
                //textView.setText("Beacon disconnected");
            }

            @Override
            public void didDetermineStateForRegion(int i, Region region) {
                Log.i(TAG, "I have just switched from seeing/not seeing beacons: " + i);
            }
        });
        mBeaconManager.addRangeNotifier(this);

        try {
            mBeaconManager.startMonitoring(new Region("test", null,null, null));
            mBeaconManager.startRangingBeacons(new Region("test", null, null, null));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mBeaconManager != null) {
            mBeaconManager.removeAllMonitorNotifiers();
            mBeaconManager.removeAllRangeNotifiers();
        }
    }

    @Override
    public void didRangeBeaconsInRegion(Collection<Beacon> beacons, Region region) {
        if (beacons.size() > 0) {
            Log.i(TAG, "The first beacon I see is about " + ((Beacon) beacons.iterator().next()).getDistance() + " meters away.");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 1){
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED){
                showToast("Permission Granted");
            }
            else {
                showToast("Permission Denied");
            }
        }
    }

    //Toast message function
    private void showToast (String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }
}
